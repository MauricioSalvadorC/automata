// Crear el autómata para generar un lenguaje específico
const automataGeneradorLenguaje = new Automata("Generador de Lenguaje");

// Crear nodos (estados)
const q0 = new Nodo("q0", false); // Estado inicial y final
const q1 = new Nodo("q1", false);
const q2 = new Nodo("q2", false);
const q3 = new Nodo("q3", false);
const q4 = new Nodo("q4", false); // Otro estado final
const q5 = new Nodo("q5", false);
const q6 = new Nodo("q6", false);
const q7 = new Nodo("q7", false); 
const q8 = new Nodo("q8", false);
const q9 = new Nodo("q9", true);

// Definir transiciones (arcos)
q0.agregarArco("q1", "a", "a", "R"); // Procesar "a" y convertirlo a "A"
q0.agregarArco("q2", "b", "b", "R"); // Aceptar si la palabra está vacía

q1.agregarArco("q1", "a", "a", "R"); // Procesar "b" y convertirlo a "B"
q1.agregarArco("q2", "b", "b", "R"); // Al encontrar "c", moverse a la izquierda
q1.agregarArco("q3", "d", "d", "R"); // Continuar procesando "B" hacia la izquierda

q2.agregarArco("q2", "b", "b", "R"); // Continuar procesando "B" hacia la izquierda
q2.agregarArco("q3", "d", "d", "R"); // Regresar al inicio con "A"

q3.agregarArco("q3", "d", "d", "R"); // Procesar "B" hacia la derecha
q3.agregarArco("q4", "#", "#", "L"); // Continuar procesando "C" hacia la derecha

q4.agregarArco("q4", "a", "a", "L"); // Continuar procesando "B" hacia la izquierda
q4.agregarArco("q4", "b", "b", "L"); // Regresar al inicio con "A"
q4.agregarArco("q4", "d", "d", "L"); // Continuar procesando "B" hacia la izquierda
q4.agregarArco("q5", "#", "#", "R");

q5.agregarArco("q6", "b", "Y", "R"); // Continuar procesando "B" hacia la izquierda
q5.agregarArco("q6", "a", "X", "R"); // Continuar procesando "B" hacia la izquierda
q5.agregarArco("q8", "d", "d", "L"); // Regresar al inicio con "A"

q6.agregarArco("q6", "a", "a", "R"); // Continuar procesando "B" hacia la izquierda
q6.agregarArco("q6", "b", "b", "R"); // Regresar al inicio con "A"
q6.agregarArco("q6", "d", "d", "R");
q6.agregarArco("q6", "e", "e", "R");
q6.agregarArco("q7", "#", "e", "L");

q7.agregarArco("q7", "e", "e", "L"); // Continuar procesando "B" hacia la izquierda
q7.agregarArco("q7", "d", "d", "L");
q7.agregarArco("q7", "b", "b", "L");
q7.agregarArco("q7", "a", "a", "L");
q7.agregarArco("q5", "X", "X", "R");
q7.agregarArco("q5", "Y", "Y", "R");

q8.agregarArco("q8", "X", "a", "L"); // Continuar procesando "B" hacia la izquierda
q8.agregarArco("q8", "Y", "b", "L"); // Regresar al inicio con "A"
q8.agregarArco("q9", "#", "#", "R");


// Agregar nodos al autómata
automataGeneradorLenguaje.agregarNodo(q0);
automataGeneradorLenguaje.agregarNodo(q1);
automataGeneradorLenguaje.agregarNodo(q2);
automataGeneradorLenguaje.agregarNodo(q3);
automataGeneradorLenguaje.agregarNodo(q4);
automataGeneradorLenguaje.agregarNodo(q5);
automataGeneradorLenguaje.agregarNodo(q6);
automataGeneradorLenguaje.agregarNodo(q7);
automataGeneradorLenguaje.agregarNodo(q8);
automataGeneradorLenguaje.agregarNodo(q9);

// Simular una palabra en el autómata
console.log(automataGeneradorLenguaje.toString());
console.log(automataGeneradorLenguaje);