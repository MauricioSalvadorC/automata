const resultado = document.querySelector("#resultado");
const tapeContainer = document.querySelector("#tape-container");
const opcionesContainer = document.querySelector("#opciones-container");
let tape = [];
let headPosition = 0;
let currentNode = null;
let isAutomatic = false; // Bandera para activar modo automático

function renderTape() {
    tapeContainer.innerHTML = "";
    tape.forEach((cell, index) => {
        const cellDiv = document.createElement("div");
        cellDiv.className = "tape-cell";
        cellDiv.textContent = cell;
        if (index === headPosition) {
            cellDiv.style.backgroundColor = "#d4edda"; // Resalta la posición actual
        }
        tapeContainer.appendChild(cellDiv);
    });
}

async function mostrarOpciones(estado) {
    if (isAutomatic) {
        processAutomatically();
        return;
    }

    opcionesContainer.innerHTML = "<h3>Selecciona el siguiente símbolo:</h3>";
    const arcos = estado.arcos;
    arcos.forEach((arco) => {
        const boton = document.createElement("button");
        boton.textContent = arco.esta;
        boton.onclick = () => {
            procesarTransicion(arco);
        };
        opcionesContainer.appendChild(boton);
    });
}

function procesarTransicion(arco) {
    resultado.innerHTML += `(${currentNode.nombre}, ${tape.join("")}, ${headPosition}) -> 
                             ${arco.esta} -> (${arco.apunta}, ${arco.reemplazo}, ${arco.dir})\n`;

    // Reemplazar símbolo en la cinta
    if (headPosition >= 0 && headPosition < tape.length) {
        tape[headPosition] = arco.reemplazo;
    } else {
        tape[headPosition] = arco.reemplazo;
    }

    // Mover la cabeza
    if (arco.dir === "R") {
        headPosition++;
    } else if (arco.dir === "L") {
        headPosition--;
    }

    renderTape();

    // Cambiar al siguiente estado
    currentNode = automataGeneradorLenguaje.obtenerNodo(arco.apunta);

    // Verificar si es un estado final
    if (currentNode?.esFinal) {
        resultado.innerHTML += `Estado final alcanzado: ${currentNode.nombre}\n`;
        opcionesContainer.innerHTML = "<h3>¡Estado final alcanzado!</h3>";
        return;
    }

    // Activar modo automático si se alcanza el estado específico
    if (currentNode.nombre === "q4") { // Cambiar "q4" por el estado deseado
        isAutomatic = true;
        processAutomatically();
        return;
    }

    mostrarOpciones(currentNode);
}

async function processAutomatically() {
    while (currentNode) {
        const arco = currentNode.arcos.find((arco) => arco.esta === tape[headPosition] || arco.esta === "#");

        if (!arco) {
            resultado.innerHTML += `No se encontró transición para (${currentNode.nombre}, ${tape[headPosition]}).\n`;
            break;
        }

        // Mostrar información de la transición
        resultado.innerHTML += `(${currentNode.nombre}, ${tape.join("")}, ${headPosition}) -> 
                                 ${arco.esta} -> (${arco.apunta}, ${arco.reemplazo}, ${arco.dir})\n`;

        // Realizar los cambios en la cinta y mover la cabeza
        if (headPosition >= 0 && headPosition < tape.length) {
            tape[headPosition] = arco.reemplazo;
        } else {
            tape[headPosition] = arco.reemplazo;
        }

        if (arco.dir === "R") {
            headPosition++;
        } else if (arco.dir === "L") {
            headPosition--;
        }

        // Actualizar la cinta y nodo actual
        renderTape();
        await animarTransicion(currentNode.nombre); // Añade animación visual
        currentNode = automataGeneradorLenguaje.obtenerNodo(arco.apunta);

        // Si se alcanza un estado final
        if (currentNode?.esFinal) {
            resultado.innerHTML += `Estado final alcanzado: ${currentNode.nombre}\n`;
            opcionesContainer.innerHTML = "<h3>¡Estado final alcanzado!</h3>";
            break;
        }

        // Pausar antes de la siguiente transición
        await new Promise((resolve) => setTimeout(resolve, 1000)); // Pausa de 1 segundo entre transiciones
    }
}

async function animarTransicion(estadoId) {
    const nodo = document.querySelector(`#node-${estadoId}`);
    if (nodo) {
        nodo.style.fill = "yellow"; // Resalta el nodo actual
        await new Promise((resolve) => setTimeout(resolve, 500)); // Pausa de 0.5 segundos
        nodo.style.fill = ""; // Restaurar color
    }
}

function iniciarSimulacion() {
    tape = [];
    headPosition = 0;
    resultado.innerHTML = "";
    isAutomatic = false; // Reiniciar el modo automático
    currentNode = automataGeneradorLenguaje.obtenerPrimerNodo();
    animarTransicion(currentNode.nombre);
    
    renderTape();
    mostrarOpciones(currentNode);
}

const svg = document.querySelector("#state-visualization");

const estados = [
    { id: "q0", x: 100, y: 100 },
    { id: "q1", x: 300, y: 100 },
    { id: "q2", x: 500, y: 100 },
    { id: "q3", x: 700, y: 100 },
    { id: "q4", x: 300, y: 300 },
    { id: "q5", x: 500, y: 300 },
    { id: "q6", x: 700, y: 300 },
    { id: "q7", x: 300, y: 500 },
    { id: "q8", x: 500, y: 500 },
    { id: "q9", x: 700, y: 500 }
];

const transiciones = [
    { origen: "q0", destino: "q1", simbolo: "a" },
    { origen: "q0", destino: "q2", simbolo: "b" },
    { origen: "q1", destino: "q1", simbolo: "a" },
    { origen: "q1", destino: "q2", simbolo: "b" },
    { origen: "q1", destino: "q3", simbolo: "d" },
    { origen: "q2", destino: "q2", simbolo: "b" },
    { origen: "q2", destino: "q3", simbolo: "d" },
    { origen: "q3", destino: "q3", simbolo: "d" },
    { origen: "q3", destino: "q4", simbolo: "#" },
    { origen: "q4", destino: "q4", simbolo: "a" },
    { origen: "q4", destino: "q4", simbolo: "b" },
    { origen: "q4", destino: "q4", simbolo: "d" },
    { origen: "q4", destino: "q5", simbolo: "#" },
    { origen: "q5", destino: "q6", simbolo: "Y" },
    { origen: "q5", destino: "q6", simbolo: "X" },
    { origen: "q5", destino: "q8", simbolo: "d" },
    { origen: "q6", destino: "q6", simbolo: "a" },
    { origen: "q6", destino: "q6", simbolo: "b" },
    { origen: "q6", destino: "q6", simbolo: "d" },
    { origen: "q6", destino: "q6", simbolo: "e" },
    { origen: "q6", destino: "q7", simbolo: "e" },
    { origen: "q7", destino: "q7", simbolo: "e" },
    { origen: "q7", destino: "q7", simbolo: "d" },
    { origen: "q7", destino: "q7", simbolo: "b" },
    { origen: "q7", destino: "q7", simbolo: "a" },
    { origen: "q7", destino: "q5", simbolo: "X" },
    { origen: "q7", destino: "q5", simbolo: "Y" },
    { origen: "q8", destino: "q8", simbolo: "X" },
    { origen: "q8", destino: "q8", simbolo: "Y" },
    { origen: "q8", destino: "q9", simbolo: "#" }
];

// Dibujar nodos y transiciones
function dibujarNodos() {
    estados.forEach(({ id, x, y }) => {
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("class", "node");
        circle.setAttribute("cx", x);
        circle.setAttribute("cy", y);
        circle.setAttribute("r", 30);
        circle.setAttribute("id", id);
        svg.appendChild(circle);

        const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        text.setAttribute("class", "text");
        text.setAttribute("x", x);
        text.setAttribute("y", y + 5); // Ajuste para centrar el texto
        text.textContent = id;
        svg.appendChild(text);
    });
}

function dibujarTransiciones() {
    transiciones.forEach(({ origen, destino }) => {
        const origenNodo = estados.find((n) => n.id === origen);
        const destinoNodo = estados.find((n) => n.id === destino);

        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("class", "line");
        line.setAttribute("x1", origenNodo.x);
        line.setAttribute("y1", origenNodo.y);
        line.setAttribute("x2", destinoNodo.x);
        line.setAttribute("y2", destinoNodo.y);
        svg.appendChild(line);
    });
}

// Animar transición
async function animarTransicion(estadoActual) {
  const nodo = document.querySelector(`#${estadoActual}`);
  if (nodo) {
      nodo.classList.add("active");
      await new Promise((resolve) => setTimeout(resolve, 500));
      nodo.classList.remove("active");
  }
}

// Mantiene el dibujo de nodos y transiciones tal cual
dibujarNodos(automataGeneradorLenguaje);
dibujarTransiciones(automataGeneradorLenguaje);
