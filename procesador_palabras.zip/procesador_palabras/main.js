const resultado = document.querySelector("#resultado");
const tapeContainer = document.querySelector("#tape-container");

// Cinta y posición inicial
let tape = [];
let headPosition = 0;

// Función para mostrar la cinta en el DOM
function renderTape() {
    tapeContainer.innerHTML = "";
    tape.forEach((cell, index) => {
        const cellDiv = document.createElement("div");
        cellDiv.className = "tape-cell";
        cellDiv.textContent = cell;
        if (index === headPosition) {
            cellDiv.style.backgroundColor = "#d4edda"; // Resalta la posición actual
        }
        tapeContainer.appendChild(cellDiv);
    });
}

// Simular paso a paso
async function simulateStep(automaton, inputTape) {
    resultado.innerHTML = "";
    tape = inputTape.split(""); // Inicializar cinta con la entrada
    headPosition = 0;
    renderTape();

    const maxSteps = 3000; // Evitar bucles infinitos
    let steps = 0;
    let currentNode = automaton.obtenerPrimerNodo();

    while (currentNode) {
      await animarTransicion(currentNode.nombre);
        if (steps >= maxSteps) {
            resultado.innerHTML += "Se alcanzó el límite máximo de pasos.\n";
            break;
        }
        steps++;

        const currentSymbol = tape[headPosition] || "#";
        const arc = currentNode.arcos.find((arco) => arco.esta === currentSymbol);

        if (arc) {
            // Mostrar el estado y la transición
            resultado.innerHTML += `(${currentNode.nombre}, ${tape.join("")}, ${headPosition}) 
              -> ${arc.esta} -> (${arc.apunta}, ${arc.reemplazo}, ${arc.dir})\n`;

            // Reemplazar símbolo en la cinta
            if (headPosition >= 0 && headPosition < tape.length) {
                tape[headPosition] = arc.reemplazo;
            }

            // Mover la cabeza
            if (arc.dir === "R") {
                headPosition++;
            } else if (arc.dir === "L") {
                headPosition--;
            }

            // Cambiar al siguiente estado
            currentNode = automaton.obtenerNodo(arc.apunta);

            // Animar movimiento
            renderTape();
            tapeContainer.style.transform = `translateX(-${headPosition * 50}px)`;
            await new Promise((r) => setTimeout(r, 500)); // Pausa para la animación
        } else {
            resultado.innerHTML += `No se encontró transición para (${currentNode.nombre}, ${currentSymbol}).\n`;
            break;
        }

        if (currentNode?.esFinal) {
            resultado.innerHTML += `Estado final alcanzado: ${currentNode.nombre}\n`;
            break;
        }
    }
}

// Función para procesar
function procesar() {
    const w = document.querySelector("#w").value;
    if (!w) {
        alert("Por favor ingresa una palabra para procesar.");
        return;
    }
    simulateStep(automataValidarW, w);
}

const svg = document.querySelector("#state-visualization");

// Configuración de nodos y transiciones
const estados = [
    { id: "qi", x: 100, y: 100 },
    { id: "qi1", x: 300, y: 100 },
    { id: "qi2", x: 500, y: 100 },
    { id: "qi3", x: 700, y: 100 },
    { id: "qi4", x: 300, y: 300 },
    { id: "qi5", x: 500, y: 300 },
    { id: "qi6", x: 700, y: 300 },
    { id: "qi7", x: 300, y: 500 },
    { id: "qi8", x: 500, y: 500 },
    { id: "qi9", x: 700, y: 500 },
    { id: "qi10", x: 300, y: 700 },
    { id: "qi11", x: 500, y: 700 },
];

const transiciones = [
    { origen: "qi", destino: "qi1", simbolo: "a" },
    { origen: "qi1", destino: "qi1", simbolo: "b" },
    { origen: "qi1", destino: "qi1", simbolo: "a" },
    { origen: "qi1", destino: "qi1", simbolo: "D" },
    { origen: "qi1", destino: "qi2", simbolo: "d" },
    { origen: "qi2", destino: "qi2", simbolo: "a" },
    { origen: "qi2", destino: "qi2", simbolo: "b" },
    { origen: "qi2", destino: "qi2", simbolo: "D" },
    { origen: "qi2", destino: "qi3", simbolo: "A" },
    { origen: "qi3", destino: "qi1", simbolo: "a" },
    { origen: "qi3", destino: "qi6", simbolo: "D" },
    { origen: "qi3", destino: "qi4", simbolo: "b" },
    { origen: "qi4", destino: "qi4", simbolo: "E" },
    { origen: "qi4", destino: "qi4", simbolo: "D" },
    { origen: "qi4", destino: "qi4", simbolo: "b" },
    { origen: "qi4", destino: "qi5", simbolo: "e" },
    { origen: "qi5", destino: "qi5", simbolo: "E" },
    { origen: "qi5", destino: "qi5", simbolo: "D" },
    { origen: "qi5", destino: "qi5", simbolo: "b" },
    { origen: "qi5", destino: "qi3", simbolo: "B" },
    { origen: "qi6", destino: "qi6", simbolo: "E" },
    { origen: "qi6", destino: "qi6", simbolo: "D" },
    { origen: "qi6", destino: "qi7", simbolo: "#" },
    { origen: "qi7", destino: "qi8", simbolo: "d" },
    { origen: "qi7", destino: "qi8", simbolo: "E" },
    { origen: "qi7", destino: "qi11", simbolo: "D" },
    { origen: "qi8", destino: "qi8", simbolo: "d" },
    { origen: "qi8", destino: "qi8", simbolo: "E" },
    { origen: "qi8", destino: "qi9", simbolo: "D" },
    { origen: "qi9", destino: "qi9", simbolo: "E" },
    { origen: "qi9", destino: "qi9", simbolo: "d" },
    { origen: "qi9", destino: "qi10", simbolo: "e" },
    { origen: "qi10", destino: "qi7", simbolo: "E" },
    { origen: "qi10", destino: "qi11", simbolo: "d" },
    { origen: "qi11", destino: "qi11", simbolo: "d" },
    { origen: "qi11", destino: "qi11", simbolo: "D" },
    { origen: "qi11", destino: "qi11", simbolo: "A" },
    { origen: "qi11", destino: "qi11", simbolo: "B" },
    { origen: "qi11", destino: "qi", simbolo: "#" },
];


// Dibujar nodos y transiciones
function dibujarNodos() {
    estados.forEach(({ id, x, y }) => {
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("class", "node");
        circle.setAttribute("cx", x);
        circle.setAttribute("cy", y);
        circle.setAttribute("r", 30);
        circle.setAttribute("id", id);
        svg.appendChild(circle);

        const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        text.setAttribute("class", "text");
        text.setAttribute("x", x);
        text.setAttribute("y", y + 5); // Ajuste para centrar el texto
        text.textContent = id;
        svg.appendChild(text);
    });
}

function dibujarTransiciones() {
    transiciones.forEach(({ origen, destino }) => {
        const origenNodo = estados.find((n) => n.id === origen);
        const destinoNodo = estados.find((n) => n.id === destino);

        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("class", "line");
        line.setAttribute("x1", origenNodo.x);
        line.setAttribute("y1", origenNodo.y);
        line.setAttribute("x2", destinoNodo.x);
        line.setAttribute("y2", destinoNodo.y);
        svg.appendChild(line);
    });
}

// Animar transición
async function animarTransicion(estadoActual) {
  const nodo = document.querySelector(`#${estadoActual}`);
  if (nodo) {
      nodo.classList.add("active");
      await new Promise((resolve) => setTimeout(resolve, 500));
      nodo.classList.remove("active");
  }
}

// Inicializar visualización
dibujarNodos(automataValidarW);
dibujarTransiciones(automataValidarW);

