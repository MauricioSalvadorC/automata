/////////////////////////////////////////////////////////////////////////////////////
// Crear el autómata multiplicación infinita
const automataValidarW = new Automata("Procesar palabra W");


// Crear nodos (estados)
var qi = new Nodo("qi", true); // Estado inicial
var qi1 = new Nodo("qi1", false);
var qi2 = new Nodo("qi2", false);
var qi3 = new Nodo("qi3", false);
var qi4 = new Nodo("qi4", false);
var qi5 = new Nodo("qi5", false);
var qi6 = new Nodo("qi6", false);
var qi7 = new Nodo("qi7", false);
var qi8 = new Nodo("qi8", false);
var qi9 = new Nodo("qi9", false);
var qi10 = new Nodo("qi10", false);
var qi11 = new Nodo("qi11", false);

// Agregar arcos
qi.agregarArco("qi1", "a", "A", "R");

qi1.agregarArco("qi1", "b", "b", "R");
qi1.agregarArco("qi1", "a", "a", "R");
qi1.agregarArco("qi1", "D", "D", "R");
qi1.agregarArco("qi2", "d", "D", "L");

qi2.agregarArco("qi2", "a", "a", "L");
qi2.agregarArco("qi2", "b", "b", "L");
qi2.agregarArco("qi2", "D", "D", "L");
qi2.agregarArco("qi3", "A", "A", "R");

qi3.agregarArco("qi1", "a", "A", "R");
qi3.agregarArco("qi6", "D", "D", "R");
qi3.agregarArco("qi4", "b", "B", "R");

qi4.agregarArco("qi4", "E", "E", "R");
qi4.agregarArco("qi4", "D", "D", "R");
qi4.agregarArco("qi4", "b", "b", "R");
qi4.agregarArco("qi5", "e", "E", "L");

qi5.agregarArco("qi5", "E", "E", "L");
qi5.agregarArco("qi5", "D", "D", "L");
qi5.agregarArco("qi5", "b", "b", "L");
qi5.agregarArco("qi3", "B", "B", "R");

qi6.agregarArco("qi6", "E", "E", "R");
qi6.agregarArco("qi6", "D", "D", "R");
qi6.agregarArco("qi7", "#", "#", "L");

qi7.agregarArco("qi8", "d", "d", "L");
qi7.agregarArco("qi8", "E", "e", "L");
qi7.agregarArco("qi11", "D", "d", "L");

qi8.agregarArco("qi8", "d", "d", "L");
qi8.agregarArco("qi8", "E", "E", "L");
qi8.agregarArco("qi9", "D", "d", "R");

qi9.agregarArco("qi9", "E", "E", "R");
qi9.agregarArco("qi9", "d", "d", "R");
qi9.agregarArco("qi10", "e", "e", "L");

qi10.agregarArco("qi7", "E", "e", "L");
qi10.agregarArco("qi11", "d", "d", "L");

qi11.agregarArco("qi11", "d", "d", "L");
qi11.agregarArco("qi11", "D", "d", "L");
qi11.agregarArco("qi11", "A", "a", "L");
qi11.agregarArco("qi11", "B", "b", "L");
qi11.agregarArco("qi", "#", "#", "R");


// Agregar nodos al autómata
automataValidarW.agregarNodo(qi);
automataValidarW.agregarNodo(qi1);
automataValidarW.agregarNodo(qi2);
automataValidarW.agregarNodo(qi3);
automataValidarW.agregarNodo(qi4);
automataValidarW.agregarNodo(qi5);
automataValidarW.agregarNodo(qi6);
automataValidarW.agregarNodo(qi7);
automataValidarW.agregarNodo(qi8);
automataValidarW.agregarNodo(qi9);
automataValidarW.agregarNodo(qi10);
automataValidarW.agregarNodo(qi11);

// Mostrar el autómata
console.log(automataValidarW.toString());
console.log(automataValidarW);